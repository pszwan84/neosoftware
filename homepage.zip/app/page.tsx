import Banner from "@/components/Banner"
import Navigation from "@/components/Navigation"

export default function Home() {
  return (
    <main className="min-h-screen">
      <Navigation />
      <Banner />
    </main>
  )
}

